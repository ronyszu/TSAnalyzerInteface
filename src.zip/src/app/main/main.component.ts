import { Component, OnInit } from '@angular/core';
import { HttpService } from './services/http.service';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})
export class MainComponent implements OnInit {


  dataa:any = 1;

  constructor(private httpService:HttpService) { }

  ngOnInit(): void {





  }


  sendData(data:any){

    this.httpService.getMeanSDandVar(data).subscribe((ans:any) => {
      console.log(ans)
    })

  }


}
